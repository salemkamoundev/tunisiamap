import { Component, OnInit } from '@angular/core';
import { LeafletModule } from '/ngx-leaflet';
import { Map, tileLayer, marker, LatLngExpression, Marker, Icon } from 'leaflet';
import { MapDataService, Location } from './services/map-data.service';
// Import pour s'assurer que les images sont bien chargées
import 'leaflet/dist/images/marker-icon.png';
import 'leaflet/dist/images/marker-shadow.png';


@Component({
  selector: 'app-map',
  standalone: true,
  imports: [LeafletModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  // Options de Leaflet: Centrer la Tunisie et définir le niveau de zoom
  options = {
    layers: [
      tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18,
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      })
    ],
    zoom: 7, // Zoom pour voir toute la Tunisie
    center: [34.0, 9.0] as LatLngExpression // Centre de la Tunisie (approximatif)
  };

  layers: Marker[] = []; // Tableau pour stocker tous les marqueurs

  // Définition d'une icône personnalisée pour les marqueurs
  private defaultIcon: Icon = new Icon({
    iconUrl: 'assets/marker-icon.png',
    shadowUrl: 'assets/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });

  constructor(private mapDataService: MapDataService) { }

  ngOnInit(): void {
    this.loadMarkers();
  }

  loadMarkers(): void {
    this.mapDataService.getLocations().subscribe(locations => {
      this.layers = locations
        .filter(loc => loc.lat && loc.lng) // Filtre les entrées sans coordonnées valides
        .map(location => {
          const markerLayer = marker([location.lat, location.lng], { icon: this.defaultIcon });
          
          // Ajout d'une popup avec les informations du lieu
          markerLayer.bindPopup(`<b>${location.nom}</b><br>${location.categorie}`);
          
          return markerLayer;
        });
      console.log(`Chargement de ${this.layers.length} lieux sur la carte.`);
    });
  }

  onMapReady(map: Map) {
    // Événement après le chargement de la carte
  }
}
